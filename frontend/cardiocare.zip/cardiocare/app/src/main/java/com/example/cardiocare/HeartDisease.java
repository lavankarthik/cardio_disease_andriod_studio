package com.example.cardiocare;

public class HeartDisease {
    public String Age;
    public String Sex;
    public String Cp;
    public String Trestbps;
    public String Chol;
    public String Reatecg;
    public String Fbs;
    public String Thalach;
    public String Exang;
    public String Oldpeak;
    public String Slope;
    public String Ca;
    public String Thal;
}
